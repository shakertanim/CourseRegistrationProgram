namespace Course_Registration_program.Models;

public class Instructor
{
    public int instructorID;
    public string lName;
    public string fName;
    public string emailID;
    public string courseName;

    public Instructor(int instructorID, string lName, string fName, string emailId, string courseName)
    {
        this.instructorID = instructorID;
        this.lName = lName;
        this.fName = fName;
        this.emailID = emailId;
        this.courseName = courseName;
    }
}