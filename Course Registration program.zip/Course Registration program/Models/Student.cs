namespace Course_Registration_program.Models;

public class Student
{
    public int studentID { get; set; }
    public string lName { get; set; }
    public string fName { get; set; }
    public string emailID { get; set; }
    public long phoneNumber { get; set; }
    public string course { get; set; }

    public Student(int studentId, string lName, string fName, string emailId, long phoneNumber, string course)
    {
        this.studentID = studentId;
        this.lName = lName;
        this.fName = fName;
        this.emailID = emailId;
        this.phoneNumber = phoneNumber;
        this.course = course;
    }
}