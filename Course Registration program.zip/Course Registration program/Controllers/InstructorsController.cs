using Course_Registration_program.Models;
using Microsoft.AspNetCore.Mvc;

namespace Course_Registration_program.Controllers;

public class InstructorsController : Controller
{
    // GET
    public IActionResult Index()
    {
        List<Instructor> instructors = new List<Instructor>()
        {
            new Instructor(100,"James","Oran","j.oran@abcd.com","Java"),
            new Instructor(101,"Orka","Bala","o.bala@abcd.com","C++"),
            new Instructor(102,"Mira","Jones","j.mira@abcd.com","Python"),
            new Instructor(103,"Sheley","Kala","s.kala@abcd.com","ASP.NET"),
            new Instructor(104,"Bor","Moore","b.moore@abcd.com","C#")
        };
        return View(instructors);
    }
    
}