using Course_Registration_program.Models;
using Microsoft.AspNetCore.Mvc;

namespace Course_Registration_program.Controllers;

public class CoursesController : Controller
{
    // GET
    public IActionResult Courses()
    {
        List<Course> courses = new List<Course>()
        {
            new Course(201, 1010, "C#", "Introduction to C# programming."),
            new Course(202, 1020, "Python", "Comprehensive Python training."),
            new Course(203, 1030, "Java", "Core Java for beginners."),
            new Course(204, 1040, "C++", "Advanced techniques in C++."),
            new Course(205, 1050, "ASP.NET", "Web development with ASP.NET."),
            new Course(206, 1060, "GoLang", "Go programming for system development."),
            new Course(207, 1070, "NodeJS", "Building server-side applications using NodeJS."),
            new Course(208, 1080, "Javascript", "Mastering client-side scripting with JavaScript.")
        };

        
        return View(courses);
    }
}