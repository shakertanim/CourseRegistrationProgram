using Course_Registration_program.Models;
using Microsoft.AspNetCore.Mvc;

namespace Course_Registration_program.Controllers;

public class StudentsController : Controller
{
    // GET
    public IActionResult Students()
    {
        List<Student> students = new List<Student>()
        {
            new Student(105, "Elena", "Holt", "e.holt@xyzmail.com", 987654321,"Java"),
            new Student(106, "Rajiv", "Chandra", "r.chandra@xyzmail.com", 876543210,"C++"),
            new Student(107, "Isabella", "Martinez", "i.martinez@xyzmail.com", 765432109,"Python"),
            new Student(108, "Tom", "Barker", "t.barker@xyzmail.com", 654321098,"ASP.NET"),
            new Student(109, "Layla", "Sands", "l.sands@xyzmail.com", 543210987,"NodeJS")
        };
        
        return View(students);
    }
}